box::use(
    .,
    A,
    b = B,
    C[...],
    D[c, d],
)
